interface Coffee {
    String getIngredients();
    int getCost();
}
