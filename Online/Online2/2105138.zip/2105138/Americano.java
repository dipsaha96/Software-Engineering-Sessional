public abstract class Americano implements Coffee {
    private BasicBlackCoffee blackcoffee;

    public Americano(BasicBlackCoffee blackcoffee) {
        this.blackcoffee = blackcoffee;
    }

    @Override
    public String getIngredients() {
        return blackcoffee.getIngredients() + ", extra grinned bean";
    }

    @Override
    public int getCost() {
        return blackcoffee.getCost() + 30;
    }
}
